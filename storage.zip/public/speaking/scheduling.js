import { apiGet, qs, escapeHtml, busyStart } from "/app.js";

const elExamPeriod = qs("#examPeriod");
const elExaminer = qs("#examinerFilter");
const elReload = qs("#btnReload");
const elRecreateMeeting = qs("#btnRecreateMeeting");
const elQ = qs("#q");
const elClear = qs("#clear");
const elFrom = qs("#fromDT");
const elTo = qs("#toDT");
const elPageSize = qs("#pageSize");
const elOut = qs("#out");
const elTbody = qs("#tbody");
const elPrev = qs("#prev");
const elNext = qs("#next");
const elPageNum = qs("#pageNum");
const elPageMax = qs("#pageMax");

let _rows = [];
let _view = [];
let _page = 1;
let _examiners = [];
const _busyStops = [];

function showBusy(message) {
  const stop = busyStart(String(message || "Processing. Don't close this page. Please wait..."));
  _busyStops.push(stop);
}

function hideBusy() {
  const stop = _busyStops.length ? _busyStops.pop() : null;
  try { if (typeof stop === "function") stop(); } catch {}
}

function toDatetimeLocalValue(ms) {
  const d = new Date(Number(ms));
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function parseDatetimeLocalToMs(v) {
  const s = String(v || "").trim();
  if (!s) return null;
  const d = new Date(s);
  const ms = d.getTime();
  return Number.isFinite(ms) ? ms : null;
}

function pageSize() {
  const n = Number(elPageSize?.value || 20);
  return Number.isFinite(n) && n > 0 ? n : 20;
}

function selectedExamPeriodId() {
  const n = Number(elExamPeriod?.value || 0);
  return Number.isFinite(n) && n > 0 ? n : null;
}

async function saveSpeakingStart(slotId) {
  const sid = Number(slotId);
  if (!Number.isFinite(sid) || sid <= 0) return;
  const startEl = document.querySelector(`input.speaking-start-input[data-slot-id="${sid}"]`);
  const startUtcMs = parseDatetimeLocalToMs(startEl?.value || "");
  if (!Number.isFinite(startUtcMs) || startUtcMs <= 0) throw new Error("Invalid date/time");
  const endUtcMs = startUtcMs + (60 * 60 * 1000);
  showBusy("Saving…");
  try {
    const r = await fetch(`/api/admin/speaking-slots/${encodeURIComponent(sid)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ startUtcMs, endUtcMs }),
    });
    if (!r.ok) {
      const j = await r.json().catch(() => ({}));
      throw new Error(j.error || `HTTP ${r.status}`);
    }
    return r.json();
  } finally {
    hideBusy();
  }
}

async function saveSpeakingExaminer(slotId) {
  const sid = Number(slotId);
  if (!Number.isFinite(sid) || sid <= 0) return;
  const examinerEl = document.querySelector(`select.speaking-examiner-input[data-slot-id="${sid}"]`);
  const examinerUsername = String(examinerEl?.value || "").trim();
  if (!examinerUsername) throw new Error("Please select examiner");
  showBusy("Saving...");
  try {
    const r = await fetch(`/api/admin/speaking-slots/${encodeURIComponent(sid)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ examinerUsername }),
    });
    if (!r.ok) {
      const j = await r.json().catch(() => ({}));
      throw new Error(j.error || `HTTP ${r.status}`);
    }
    return r.json();
  } finally {
    hideBusy();
  }
}

async function loadExaminers() {
  const rows = await apiGet("/api/admin/examiners");
  _examiners = (Array.isArray(rows) ? rows : [])
    .map((r) => String(r?.username || "").trim())
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b));
}

function hydrateExaminerFilter(rows) {
  const current = String(elExaminer?.value || "");
  const names = Array.from(new Set([
    ..._examiners,
    ...(rows || []).map((r) => String(r.examinerUsername || "").trim()).filter(Boolean),
  ])).sort((a, b) => a.localeCompare(b));
  if (!elExaminer) return;
  elExaminer.innerHTML = `<option value="">All examiners</option>` + names.map((x) => `<option value="${escapeHtml(x)}">${escapeHtml(x)}</option>`).join("");
  if (names.includes(current)) elExaminer.value = current;
}

function buildExaminerOptions(selectedUsername) {
  const selected = String(selectedUsername || "").trim();
  const names = Array.from(new Set([
    ..._examiners,
    selected,
  ].filter(Boolean))).sort((a, b) => a.localeCompare(b));

  if (!names.length) return `<option value="">No examiners</option>`;
  return names.map((name) => {
    const safe = escapeHtml(name);
    const sel = name === selected ? " selected" : "";
    return `<option value="${safe}"${sel}>${safe}</option>`;
  }).join("");
}

function applyFilters() {
  const q = String(elQ?.value || "").trim().toLowerCase();
  const ex = String(elExaminer?.value || "").trim().toLowerCase();
  const fromMs = parseDatetimeLocalToMs(elFrom?.value || "");
  const toMs = parseDatetimeLocalToMs(elTo?.value || "");

  _view = (_rows || []).filter((r) => {
    if (ex) {
      const rx = String(r.examinerUsername || "").trim().toLowerCase();
      if (rx !== ex) return false;
    }
    if (Number.isFinite(fromMs) && Number(r.startUtcMs || 0) < fromMs) return false;
    if (Number.isFinite(toMs) && Number(r.startUtcMs || 0) > toMs) return false;
    if (!q) return true;
    const sessionId = Number(r.sessionId || 0);
    const slotId = Number(r.id || 0);
    const sessionIdText = Number.isFinite(sessionId) && sessionId > 0 ? String(sessionId) : "";
    const sessionIdPad = sessionIdText ? sessionIdText.padStart(6, "0") : "";
    const sessionCode = sessionIdPad ? `s-${sessionIdPad}` : "";
    const blob = [
      String(r.candidateName || ""),
      String(r.sessionToken || ""),
      String(r.examinerUsername || ""),
      String(slotId > 0 ? slotId : ""),
      sessionIdText,
      sessionIdPad,
      sessionCode,
    ].join(" ").toLowerCase();
    return blob.includes(q);
  });
  const max = Math.max(1, Math.ceil(_view.length / pageSize()));
  if (_page > max) _page = max;
  renderTable();
}

function renderTable() {
  const size = pageSize();
  const max = Math.max(1, Math.ceil(_view.length / size));
  if (!Number.isFinite(_page) || _page < 1) _page = 1;
  if (_page > max) _page = max;
  const start = (_page - 1) * size;
  const part = _view.slice(start, start + size);

  if (!part.length) {
    elTbody.innerHTML = `<tr><td colspan="5" class="muted">No rows</td></tr>`;
  } else {
    elTbody.innerHTML = part.map((r) => {
      const id = Number(r.id || 0);
      const candidate = escapeHtml(String(r.candidateName || ""));
      const examiner = escapeHtml(String(r.examinerUsername || ""));
      const gateUrlRaw = String(r.speakingUrl || "").trim() || (r.sessionToken
        ? `${location.origin}/speaking/?token=${encodeURIComponent(String(r.sessionToken || ""))}`
        : "");
      const gateUrl = escapeHtml(gateUrlRaw);
      const startValue = Number.isFinite(Number(r.startUtcMs)) ? toDatetimeLocalValue(Number(r.startUtcMs)) : "";
      return `
        <tr data-slot-id="${id}">
          <td>
            <div style="display:flex; gap:8px; align-items:center;">
              <input class="input mono speaking-start-input" data-slot-id="${id}" type="datetime-local" step="60" value="${escapeHtml(startValue)}" style="min-width:178px;" />
              <button class="btn speaking-time-save-btn" data-slot-id="${id}" type="button" style="width:auto; min-width:62px; padding:8px 10px;">Save</button>
            </div>
          </td>
          <td>${candidate}</td>
          <td>
            <div style="display:flex; gap:8px; align-items:center;">
              <select class="input mono speaking-examiner-input" data-slot-id="${id}" style="min-width:180px;">
                ${buildExaminerOptions(examiner)}
              </select>
              <button class="btn speaking-examiner-save-btn" data-slot-id="${id}" type="button" style="width:auto; min-width:62px; padding:8px 10px;">Save</button>
            </div>
          </td>
          <td>${gateUrlRaw ? `<a href="${gateUrl}" target="_blank" rel="noopener" class="mono">Open</a>` : "-"}</td>
          <td><button class="btn speaking-show-meeting-btn" data-slot-id="${id}" type="button" style="width:auto; min-width:92px;">Show</button></td>
        </tr>
      `;
    }).join("");
  }

  if (elPageNum) elPageNum.textContent = String(_page);
  if (elPageMax) elPageMax.textContent = String(max);
  if (elPrev) elPrev.disabled = _page <= 1;
  if (elNext) elNext.disabled = _page >= max;
}

async function autoGenerate(examPeriodId) {
  const ep = Number(examPeriodId);
  if (!Number.isFinite(ep) || ep <= 0) return null;
  showBusy("Auto-generating…");
  try {
    const r = await fetch("/api/admin/speaking-slots/auto-generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ examPeriodId: ep }),
    });
    if (!r.ok) {
      const j = await r.json().catch(() => ({}));
      throw new Error(j.error || `HTTP ${r.status}`);
    }
    return r.json();
  } finally {
    hideBusy();
  }
}

async function recreateMeetingLinks(examPeriodId) {
  const body = {};
  const ep = Number(examPeriodId || 0);
  if (Number.isFinite(ep) && ep > 0) body.examPeriodId = ep;
  const r = await fetch("/api/admin/speaking-slots/recreate-meeting-links", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    body: JSON.stringify(body),
  });
  if (!r.ok) {
    const j = await r.json().catch(() => ({}));
    throw new Error(j.error || `HTTP ${r.status}`);
  }
  return r.json();
}

async function loadRows() {
  const ep = selectedExamPeriodId();
  if (elOut) elOut.textContent = "Loading...";
  let auto = null;
  let autoErr = "";
  if (ep) {
    try {
      auto = await autoGenerate(ep);
    } catch (e) {
      autoErr = String(e?.message || "auto-generate failed");
    }
  }

  const rowsUrl = ep
    ? `/api/admin/speaking-slots?examPeriodId=${encodeURIComponent(ep)}&limit=50000`
    : `/api/admin/speaking-slots?limit=50000`;
  const rows = await apiGet(rowsUrl);
  _rows = Array.isArray(rows) ? rows : [];
  hydrateExaminerFilter(_rows);
  _page = 1;
  applyFilters();

  if (elOut) {
    const created = Number(auto?.created || 0);
    const failed = Number(auto?.failed || 0);
    const part1 = created > 0 ? ` Auto-generated ${created} new slot(s).` : "";
    const part2 = failed > 0 ? ` ${failed} failed.` : "";
    const part3 = autoErr ? ` Auto-generate skipped: ${escapeHtml(autoErr)}.` : "";
    elOut.innerHTML = `<span class="ok">Loaded ${_rows.length} slot(s).${part1}${part2}${part3}</span>`;
  }
}

async function init() {
  await loadExaminers();
  const periods = await apiGet("/api/admin/exam-periods");
  const list = Array.isArray(periods) ? periods : [];
  if (elExamPeriod) {
    elExamPeriod.innerHTML =
      `<option value="">All exam periods</option>` +
      list.map((p) => `<option value="${Number(p.id)}">${escapeHtml(String(p.name || `Exam Period ${p.id}`))}</option>`).join("");
  }
  await loadRows();
}

if (elReload) elReload.addEventListener("click", () => { loadRows().catch((e) => { if (elOut) elOut.innerHTML = `<span class="bad">Error: ${escapeHtml(e.message || String(e))}</span>`; }); });
if (elRecreateMeeting) {
  elRecreateMeeting.addEventListener("click", async () => {
    try {
      elRecreateMeeting.disabled = true;
      showBusy("Recreating meeting links. Don't close this page. Please wait...");
      if (elOut) elOut.textContent = "Recreating meeting links...";
      const ep = selectedExamPeriodId();
      const out = await recreateMeetingLinks(ep);
      const done = Number(out?.updated || 0);
      const failed = Number(out?.failed || 0);
      const scope = Number(out?.examPeriodId || 0) > 0 ? `exam period ${Number(out.examPeriodId)}` : "all exam periods";
      if (elOut) elOut.innerHTML = `<span class="ok">Recreated ${done} meeting link(s) for ${escapeHtml(scope)}.</span>${failed > 0 ? ` <span class="bad">${failed} failed.</span>` : ""}`;
      await loadRows();
    } catch (e) {
      if (elOut) elOut.innerHTML = `<span class="bad">Error: ${escapeHtml(e.message || String(e))}</span>`;
    } finally {
      hideBusy();
      elRecreateMeeting.disabled = false;
    }
  });
}
if (elExamPeriod) elExamPeriod.addEventListener("change", () => { loadRows().catch((e) => { if (elOut) elOut.innerHTML = `<span class="bad">Error: ${escapeHtml(e.message || String(e))}</span>`; }); });
if (elExaminer) elExaminer.addEventListener("change", () => { _page = 1; applyFilters(); });
if (elFrom) elFrom.addEventListener("change", () => { _page = 1; applyFilters(); });
if (elTo) elTo.addEventListener("change", () => { _page = 1; applyFilters(); });
if (elQ) elQ.addEventListener("input", () => { _page = 1; applyFilters(); });
if (elPageSize) elPageSize.addEventListener("change", () => { _page = 1; applyFilters(); });
if (elClear) elClear.addEventListener("click", () => {
  if (elQ) elQ.value = "";
  if (elExaminer) elExaminer.value = "";
  if (elFrom) elFrom.value = "";
  if (elTo) elTo.value = "";
  _page = 1;
  applyFilters();
});
if (elPrev) elPrev.addEventListener("click", () => { _page = Math.max(1, _page - 1); renderTable(); });
if (elNext) elNext.addEventListener("click", () => { _page += 1; renderTable(); });

if (elTbody) {
  elTbody.addEventListener("click", async (e) => {
    const target = e.target;
    if (!(target instanceof HTMLElement)) return;

    const saveBtn = target.closest(".speaking-time-save-btn");
    if (saveBtn) {
      const slotId = Number(saveBtn.getAttribute("data-slot-id") || 0);
      try {
        if (elOut) elOut.textContent = "Saving...";
        const updated = await saveSpeakingStart(slotId);
        _rows = (_rows || []).map((x) => (Number(x.id) === slotId ? updated : x));
        _view = (_view || []).map((x) => (Number(x.id) === slotId ? updated : x));
        renderTable();
        if (elOut) elOut.innerHTML = `<span class="ok">Slot ${slotId} updated.</span>`;
      } catch (err) {
        if (elOut) elOut.innerHTML = `<span class="bad">Error: ${escapeHtml(err.message || String(err))}</span>`;
      }
      return;
    }

    const examinerSaveBtn = target.closest(".speaking-examiner-save-btn");
    if (examinerSaveBtn) {
      const slotId = Number(examinerSaveBtn.getAttribute("data-slot-id") || 0);
      try {
        if (elOut) elOut.textContent = "Saving...";
        const updated = await saveSpeakingExaminer(slotId);
        _rows = (_rows || []).map((x) => (Number(x.id) === slotId ? updated : x));
        _view = (_view || []).map((x) => (Number(x.id) === slotId ? updated : x));
        renderTable();
        if (elOut) elOut.innerHTML = `<span class="ok">Examiner updated for slot ${slotId}.</span>`;
      } catch (err) {
        if (elOut) elOut.innerHTML = `<span class="bad">Error: ${escapeHtml(err.message || String(err))}</span>`;
      }
      return;
    }

    const showMeetingBtn = target.closest(".speaking-show-meeting-btn");
    if (showMeetingBtn) {
      const slotId = Number(showMeetingBtn.getAttribute("data-slot-id") || 0);
      const row = (_rows || []).find((x) => Number(x.id) === slotId);
      const joinUrl = String(row?.joinUrl || "").trim();
      const startUrl = String(row?.startUrl || "").trim();
      const provider = String(row?.meetingMetadata?.provider || row?.videoProvider || "").trim().toLowerCase();
      const preferredUrl = provider === "zoom" && startUrl ? startUrl : joinUrl;
      if (!preferredUrl) {
        if (elOut) elOut.innerHTML = `<span class="bad">No meeting URL found for slot ${slotId}.</span>`;
        return;
      }
      try {
        await navigator.clipboard.writeText(preferredUrl);
        if (provider === "zoom" && startUrl && joinUrl && startUrl !== joinUrl) {
          if (elOut) elOut.innerHTML = `<span class="ok">Zoom host URL copied for slot ${slotId}.</span><div style="margin-top:6px;"><div class="muted">Host:</div><a class="mono" href="${escapeHtml(startUrl)}" target="_blank" rel="noopener">${escapeHtml(startUrl)}</a><div class="muted" style="margin-top:6px;">Candidate:</div><a class="mono" href="${escapeHtml(joinUrl)}" target="_blank" rel="noopener">${escapeHtml(joinUrl)}</a></div>`;
        } else {
          if (elOut) elOut.innerHTML = `<span class="ok">Meeting URL copied for slot ${slotId}.</span><br><a class="mono" href="${escapeHtml(preferredUrl)}" target="_blank" rel="noopener">${escapeHtml(preferredUrl)}</a>`;
        }
      } catch {
        if (provider === "zoom" && startUrl && joinUrl && startUrl !== joinUrl) {
          if (elOut) elOut.innerHTML = `<span class="ok">Zoom meeting URLs for slot ${slotId}:</span><div style="margin-top:6px;"><div class="muted">Host:</div><a class="mono" href="${escapeHtml(startUrl)}" target="_blank" rel="noopener">${escapeHtml(startUrl)}</a><div class="muted" style="margin-top:6px;">Candidate:</div><a class="mono" href="${escapeHtml(joinUrl)}" target="_blank" rel="noopener">${escapeHtml(joinUrl)}</a></div>`;
        } else {
          if (elOut) elOut.innerHTML = `<span class="ok">Meeting URL for slot ${slotId}:</span><br><a class="mono" href="${escapeHtml(preferredUrl)}" target="_blank" rel="noopener">${escapeHtml(preferredUrl)}</a>`;
        }
      }
    }
  });
}

init().catch((e) => {
  if (elOut) elOut.innerHTML = `<span class="bad">Error: ${escapeHtml(e.message || String(e))}</span>`;
});
